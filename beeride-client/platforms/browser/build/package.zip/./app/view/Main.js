Ext.define('Beeride.view.Main', {
	extend : 'Ext.navigation.View',
	xtype : 'main',
	config : {
		ui : 'plain',
		items : {
			xtype : 'login'
		}
	}
});