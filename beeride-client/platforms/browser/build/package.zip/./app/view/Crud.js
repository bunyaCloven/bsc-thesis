Ext.define('Beeride.view.Crud', {
	extend : 'Ext.Panel',
	xtype : 'crud',
	config : {
		layout : 'vbox',
		items : []
	}
});