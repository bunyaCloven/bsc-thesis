Ext.define('Beeride.view.Map', {
	extend : 'Ext.form.Panel',
	xtype : 'bmap',
	config : {
		items : [{
			xtype : 'map'
		}]
	}
});