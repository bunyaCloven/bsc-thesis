Ext.define('Beeride.model.Path', {
	extend : 'Ext.data.Model',
	config : {
		fields : [ {
			name : 'id',
			type : 'long'
		}, {
			name : 'name',
			type : 'string'
		} ]
	}
});